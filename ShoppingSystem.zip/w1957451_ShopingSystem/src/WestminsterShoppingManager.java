import java.io.*;
import java.util.*;


// WestminsterShoppingManager class implementing ShoppingManager interface
class WestminsterShoppingManager implements ShoppingManager {
    private static final String PRODUCT_ITEMS_FILE = "product_items.txt";
    private List<Product> productList;

    // Main Method
    public static void main(String[] args) {
        WestminsterShoppingManager shoppingManager = new WestminsterShoppingManager();
        shoppingManager.displayMenu();
    }

    // Constructor for WestminsterShoppingManager
    public WestminsterShoppingManager() {
        this.productList = new ArrayList<>();
    }

    // Implementing methods from ShoppingManager interface
    @Override
    public void addProduct(Product product) {
        productList.add(product);
    }

    @Override
    public void deleteProduct(String productID) {
        // Find the product with the specified ID
        Product productToDelete = null;
        for (Product product : productList) {
            if (product.getProductID().equals(productID)) {
                productToDelete = product;
                break;
            }
        }
        // Check if the product with the specified ID exists
        if (productToDelete != null) {
            productList.remove(productToDelete);
            System.out.println("Product deleted successfully.");
            System.out.println("Remaining products: " + productList.size());
        } else {
            System.out.println();
            System.out.println("No product found with the specified ID. Please try again.");
            System.out.println();
        }
    }


    @Override
    public void printProductList() {
        if (productList.isEmpty()) {
            System.out.println();
            System.out.println("Product List is Empty.");
            System.out.println();
        }
        productList.stream()
                .sorted(Comparator.comparing(Product::getProductID))
                .forEach(product -> {
                    System.out.println("Product ID: " + product.getProductID());
                    System.out.println("Product Name: " + product.getProductName());
                    System.out.println("Available Items: " + product.getAvailableItems());
                    System.out.println("Price: $" + product.getPrice());
                    if (product instanceof Electronics) {
                        System.out.println("Brand: " + ((Electronics) product).getBrand());
                        System.out.println("Warranty Period: " + ((Electronics) product).getWarrantyPeriod() + " months");
                    } else if (product instanceof Clothing) {
                        System.out.println("Size: " + ((Clothing) product).getSize());
                        System.out.println("Color: " + ((Clothing) product).getColor());
                    }
                    System.out.println("--------------------------");
                });
    }

    @Override
    public void saveProductListToFile(String filename) {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(PRODUCT_ITEMS_FILE))) {
            outputStream.writeObject(productList);
            System.out.println("Product list saved to file: " + PRODUCT_ITEMS_FILE);
        } catch (IOException e) {
            System.out.println("Error saving product list to file: " + e.getMessage());
        }
    }

    @Override
    public void readProductListFromFile(String filename) {
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(filename))) {
            productList = (List<Product>) inputStream.readObject();
            System.out.println("Product list loaded from file: " + filename);
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading product list from file: " + e.getMessage());
        }
    }



    // Console Main Menu
    public void displayMenu() {
        Scanner input = new Scanner(System.in);

        while (true) {
            System.out.println(""" 
                             ______________________________________
                              ===== ONLINE SHOPPING SYSTEM ======
                             ______________________________________  """);
            System.out.println("1: Add a New Product");
            System.out.println("2: Delete a Product");
            System.out.println("3: Print the List of Products");
            System.out.println("4: Save Product List to File");
            System.out.println("5: Load Product List from File");
            System.out.println("6: Exit");
            System.out.println("Enter your Choice Between (1-6): ");

            int menuNo = input.nextInt();
            input.nextLine();

            // Switch Case For

            switch (menuNo) {
                case 1:
                    addNewProduct();
                    break;
                case 2:
                    System.out.print("Enter product ID to Delete: ");
                    String productIDToDelete = input.nextLine();
                    deleteProduct(productIDToDelete);
                    break;
                case 3:
                    printProductList();
                    break;
                case 4:
                    saveProductListToFile(PRODUCT_ITEMS_FILE);
                    break;
                case 5:
                    readProductListFromFile(PRODUCT_ITEMS_FILE);
                    break;
                case 6:
                    System.out.println("Goodbye!");
                    return;
                default:
                    System.out.println();
                    System.out.println("Invalid choice. Please Enter a Number Between 1 and 6 ");
            }
        }
    }

    //  Add a new product.
    private void addNewProduct() {
        Scanner input = new Scanner(System.in);

        int productQty =0;
        for (Product pdt:productList) {
            productQty+= pdt.getAvailableItems();
        }

        if (productQty < 50) {

            System.out.print("Enter Product Type [Electronics :(1) | Clothing :(2)] : ");
            int productTypeChoice = input.nextInt();
            input.nextLine();
            if (productTypeChoice < 1 || productTypeChoice > 2) {
                System.out.println();
                System.out.println("Invalid product type choice.Try Again.");
                return;
            }
            System.out.print("Enter product ID: ");
            String productID = input.nextLine();

            System.out.print("Enter product name: ");
            String productName = input.nextLine();

            System.out.print("Enter Quantity of Available Items : ");
            if(!(input.hasNextInt())){
                System.out.println("Enter a valid input!");
                return;
            }
            int availableItems = input.nextInt();


            System.out.print("Enter Price: ");
            if(!(input.hasNextDouble())){
                System.out.println("Enter a valid input!");
                return;
            }
            double price = input.nextDouble();
            input.nextLine();

            if (productTypeChoice == 1) {
                System.out.print("Enter Brand: ");
                String brand = input.nextLine();

                System.out.print("Enter Warranty Period (in months): ");
                if(!(input.hasNextInt())) {
                    System.out.println("Enter a valid input!");
                    return;
                }
                int warrantyPeriod = input.nextInt();

                if((productQty+availableItems)>50){
                    System.out.println("Product stock is exceeded; Cannot add the product!");
                    return;
                }

                Electronics electronicsProduct = new Electronics(productID, productName, availableItems, price, brand, warrantyPeriod);
                addProduct(electronicsProduct);
                System.out.println();
                System.out.println("Product added successfully");

            } else if (productTypeChoice == 2) {
                System.out.print("Enter Size: ");
                String size = input.nextLine();

                System.out.print("Enter Color: ");
                String color = input.nextLine();

                if((productQty+availableItems)>50){
                    System.out.println("Product stock is exceeded; Cannot add more products!!!!");
                    return;
                }

                Clothing clothingProduct = new Clothing(productID, productName, availableItems, price, size, color);
                addProduct(clothingProduct);
                System.out.println();
                System.out.println("Product added successfully");
            }
        }else {
            System.out.println ("Product stock is exceeded; Cannot add more products!!!!");
        }

    }


}