import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;

// ShoppingCart class
class ShoppingCart implements Serializable{
    private List<Product> productList;

    // Constructor for ShoppingCart
    public ShoppingCart() {
        this.productList = new ArrayList<>();
    }

    // Methods to add, remove, and calculate total cost
    public void addProduct(Product product) {
        productList.add(product);

    }


    public void removeProduct(String productID) {
        productList.removeIf(product -> product.getProductID().equals(productID));
    }

    public double calculateTotalCost() {
        return productList.stream().mapToDouble(Product::getPrice).sum();
    }
}
