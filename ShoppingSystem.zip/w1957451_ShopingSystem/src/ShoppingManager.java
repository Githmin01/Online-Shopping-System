// Interface for ShoppingManager
interface ShoppingManager {
    void addProduct(Product product);

    void deleteProduct(String productID);

    void printProductList();

    void saveProductListToFile(String filename);

    void readProductListFromFile(String filename);
}