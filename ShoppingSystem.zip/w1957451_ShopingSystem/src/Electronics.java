import java.io.Serializable;
// Electronics subclass

class Electronics extends Product implements Serializable {
    private String brand;
    private int warrantyPeriod;
    // Default Constructor
    public Electronics(String productID, String productName, int availableItems, double price) {
        super(productID, productName, availableItems, price);
    }

    // Full Arg Constructor for Electronics
    public Electronics(String productID, String productName, int availableItems, double price, String brand, int warrantyPeriod) {
        super(productID, productName, availableItems, price);
        this.brand = brand;
        this.warrantyPeriod = warrantyPeriod;
    }

    // Getter and setter methods for Electronics attributes
    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getWarrantyPeriod() {
        return warrantyPeriod;
    }

    public void setWarrantyPeriod(int warrantyPeriod) {
        this.warrantyPeriod = warrantyPeriod;
    }
}
