import java.io.Serializable;
// Clothing subclass
class Clothing extends Product implements Serializable {
    private String size;
    private String color;

    // Full Arg Constructor for Clothing
    public Clothing(String productID, String productName, int availableItems, double price, String size, String color) {
        super(productID, productName, availableItems, price);
        this.size = size;
        this.color = color;
    }

    // Getter and setter methods for Clothing attributes
    public String getSize() {
        return size;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    public void setSize(String size) {
        this.size = size;
    }
}
